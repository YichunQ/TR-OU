function [t,Err] = tr_ALS(input,Tol,Rank,maxit)
        c=input;
        n = size(c);
        n = n(:);
        d = numel(n);
        node=cell(1,d);
        r=Rank(:);
        for i=1:d-1
            node{i}=randn(r(i),n(i),r(i+1));
        end
        node{d}=randn(r(d),n(d),r(1));
        od=(1:d)';
        err=1;
        Err = repmat(Tol,[maxit*d,1]);
        for it=1:maxit*d
            err0=err;
            if it>1
                c=shiftdim(c,1);
                od=circshift(od,-1);
            end
            c=reshape(c,n(od(1)),numel(c)/n(od(1)));
            b=node{od(2)};
            for k=3:d
                j=od(k);
                br=node{j};
                br=reshape(br,[r(j),numel(br)/r(j)]);
                b=reshape(b,[numel(b)/r(j),r(j)]);
                b=b*br;
            end
            b=reshape(b,[r(od(2)),prod(n(od(2:end))),r(od(1))]);
            b=permute(b,[1,3,2]);
            b=reshape(b,[r(od(2))*r(od(1)), prod(n(od(2:end)))]);
            a=c/b;
            err=norm(c-a*b,'fro')/norm(c(:));
            a=reshape(a,[n(od(1)),r(od(2)),r(od(1))]);
            node{od(1)}=permute(a,[3,1,2]);
            s=norm(node{od(1)}(:));
            node{od(1)}=node{od(1)}./s;
            
            % fprintf('it:%d, err=%f\n',it,err);
            if abs(err0-err)<=1e-3 && it>=2*d && err<=Tol
                break;
            end
            c=reshape(c,n(od)');
            Err(it) = err;
        end
        node{od(1)}=node{od(1)}.*s;
        t.node=node;
        t.d=d;
        t.n=n;
        t.r=r;
        return;

end