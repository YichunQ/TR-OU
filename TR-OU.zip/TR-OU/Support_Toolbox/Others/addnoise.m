function Y = addnoise(X,SNR)
%  X: clean data, N: Gaussian noise, Y: noisy data
%  SNR = 20*log10(norm(tensor(X))/norm(tensor(N)));

I = size(X);
norm_X = norm(tensor(X));
noise = randn(I);
sigma = norm_X/(10^(SNR/20)*norm(tensor(noise)));  
N = sigma.*noise;
Y = X + N;


