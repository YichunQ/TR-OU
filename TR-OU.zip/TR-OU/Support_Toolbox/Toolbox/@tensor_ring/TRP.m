function A = TRP(X,method,R,sparse)
% a descrip of tensor random projection
% X is input data, R is ranks
% Y is approximation

    s = 2*R;
%     d = activemode;
    switch method
            case 'GR-SVD'  % Gauss-Rand-Projected-SVD 
                tic;
                P = randn(n, s) / sqrt(s);  % Gauss-random-projetion
                Y = X*P;
                [Q, ~] = qr(Y,0);
                B = Q'*X;
                [U,~,~] = svd(B,'econ');
                U = Q*U;
                A = U;
                t = toc(tic);
                
                
             case 'LS-SVD'  % Leverage-Sample-SVD
                tic;
                [~,~,V] = svd(X,'econ');
                leveragescores = sum(V.^2, 2);
                prob = leveragescores / sum(leveragescores);
                idx = randsample(n, s, true, prob);
                idx = unique(idx); % eliminate duplicates
                C = X(:, idx);  % Sketch-matrix
                [Q, ~] = qr(C, 0);
                B = Q'*X;
                [U, ~, ~] = svd(B,'econ');
                U = Q*U;
                A = U;
                t = toc(tic);
                
            case 'C-SVD' % CountSletch-SVD
                tic;
                C = CountSketch(X, s);  % Sketch-matrix
                [Q, ~] = qr(C, 0);
                B = Q'*X;
                [U, ~, ~] = svd(B,'econ');
                U = Q*U;
                A = U;
                t = toc(tic);
                
            case 'RI-SVD'   % Rand-Iterative-SVD
                tic;
                it = 2;  % iterations of QR
%                 p = min(2*k,n);
                if sparse
                    Y = CountSketch(X,s);
                else
                    Y = X*randn(n,s);
                end
                [Q ,~]= qr(Y,0);
                for ii = 1:it  % a power-method of GR-SVD
                    [Z,~] = qr(X'*Q,0);
                    [Q,~] = qr(X*Z,0);
                end
                B = Q'*(X*X')*Q;
                [U, ~, ~] = svd(B,'econ');
                U = Q*U;
                A = U;
                t = toc(tic);
                
          case 'BK-SVD' % rand Block-Krylov Iterative-SVD
                tic
                it = 3;
                if sparse
                    C = CountSketch(X,s);
                else
                    C = X * randn(n, s);
                end
                Krylov = zeros(m, s * it);
                Krylov(:, 1:s) = C;
                for ii = 2: it
                    C = X' * C;   % improve-RSVD:Y=(XX')qXrandn(n, s);
                    C = X * C;
                    [C, ~] = qr(C, 0); % optional
                    Krylov(:, (ii-1)*s+1: ii*s) = C;  % 3-times-Sketchsize
                end
                [Q, ~] = qr(Krylov, 0);
                B = Q'*(X*X')*Q;
                [U, ~, ~] = svd(B,'econ');
                U = Q*U;
                A = U;
                t = toc(tic);
                
                
          case 'RG-Q'  %  rand-Gauss projection+QR: IET2020
                tic;
                P = randn(n, s) / sqrt(s);  % Gauss-random-projetion
                Y = X*P;
                [Q, ~] = qr(Y,0);
                A = Q;
                t = toc(tic);
                
    end
end