function W=gen_W(S,mr)
% Generate binary tensor: W 
% with size: S and missing rate: mr

Omega = randperm(prod(S)); 
Omega = Omega(1:round((1-mr)*prod(S)));
W = zeros(S); 
W(Omega) = 1;

end