function [U,S,V,k] = iter_SVT(data, Omega, rho, tol)
% data: input data, Omega: observed set
% rho: threshold in SVT, tol: tolerance

X = double(data);
sz = size(X);
maxiter = 500;  % num of max iterations

M = zeros(sz);
Y = Omega.*X;   % or X = zeros(sz);

tau = 1/rho;

for it = 1:maxiter
    temp = Y+tau*M;
    [Z, U,S,V,k] = SVT(temp, tau);
    Y = Z - tau*M;
    Y(Omega==1) = X(Omega==1);
    M = M + rho*(Y-Z);
    err = norm(Omega.*(Y - Z))/norm(Omega.*Y);
    disp([ num2str(it), 'th Iteration: Estimated Rank = ', num2str(k), ', err=', num2str(err)]);

    if it >= maxiter || err <= tol
        break
    end  
end


