% test_demo for synthetic data

close; clear; clc


%% add path
addpath (genpath('./main_algs/'))
addpath (genpath('./Support_Toolbox/'))
addpath ('./data/')

%%%%%%%%%%%% set up %%%%%%%%%%%%%
noisy = 1;
miss = 0;   % incomplete or not
skt = 0; % sketching or not
ep = 1.5e-1;


%%%%%%%%%%%% gen_data %%%%%%%%%%%%
d = 5;
n = 10;
% rank = 3;
sz = n*ones(1,d);
% r = rank*ones(1,d);
r = [2,3,2,3,2];
node=cell(1,d);

for i=1:d-1
   node{i}=randn(r(i),sz(i),r(i+1));
end
clear i
node{d}=randn(r(d),sz(d),r(1));
tr=tensor_ring;
tr=cell2core(tr,node);
tdata=fold1(tr);
tdata = reshape(tdata,sz);
T = tdata;
norm_T = norm(tensor(tdata));
R0 = r;
disp([ 'Data size =', num2str(sz),', True Ranks = ', num2str(R0)]);
disp('===================================');


 %% Add noise
if noisy
    SNR = 20;
    data = addnoise(T,SNR);
    disp([ 'Noisy case with SNR = ', num2str(SNR), 'dB']);
    disp('===================================');
else
    data = T;
    disp( 'NoiseFree case.');
    disp('===================================');
end


%% Add　mask
if miss
    rho = 1e-4;
    mr = 0.3;
    W = gen_W(sz,mr);
    Z = W.*data;
    disp([ 'Incomplete case with MR = ', num2str(mr)]);
    disp('===================================');
else
    rho = [];
    mr = 0;
    W = ones(sz);  
    Z=data;
    disp('Complete case.');
    disp('===================================');
end
 
runs = 10;  % test runs 
Time = zeros(1,runs);  
RSE = Time;
CR = RSE;
EstRank = zeros(d,runs);

%%  Comparison
    for it = 1:runs    
        c=tic;
        [J, R, S] = rankEst_odd(Z, W, skt, miss, ep, rho);
        if miss
            para.r = R;
            para.max_iter= 50;  
            para.max_tot=10^-6;
            para.tol=10^-6;
            para.disp =0;
            para.printitn = 0; 
            tr = Completion_TR(Z, W, para);
            X = coreten2tr(tr);
        else
            tr = tr_ALS(Z,1e-6,R,20); 
            X = fold1(tr);
        end
        Time(it) = toc(c); 
        X = reshape(X,sz);
        EstRank(:,it) = R;
        RSE(it) = norm(X(:)-T(:))/norm_T;    
        CR(it) = ComRatio(sz, R);
        
    end
    Rn = round(mean(EstRank(:,:),2))';
    disp([ 'Estimated Rank = ', num2str(Rn)]);
    disp([ 'Time  = ', num2str(mean(Time))]);
    disp([ 'RSE  = ', num2str(mean(RSE))]);
    disp([ 'CR  = ', num2str(mean(CR))]);

