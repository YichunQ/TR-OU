function [X_hat,U,S,V, k] = SVT(X, tau)
% Singular Value Thresholding 

    [U, S, V] = svd(X, 'econ');
    S_thresh = max(S - tau, 0);
    k = nnz(diag(S_thresh)); 
    X_hat = U * S_thresh * V';
end
