
function  a=plus(b,c)

x =1;