function [J, R, S] = rankEst_odd(X, Omega, skt, miss, ep, rho)


%% set-up
    X = double(X);
    sz = size(X);
    td = length(sz);
    S = cell(1,td);    % eigen_values
    J = zeros(1,td);   % Unfold_ranks
    R = zeros(1,td);   % TR-ranks
    supc = 1;          % supercritical
    t = 2;

    if ~mod(td,2)
        d = td-1;
        nsz = sz(1:d-1);
        nsz(d) = prod(sz(d:td));
    else 
        d = td;
        nsz = sz;
    end 
    O = reshape(Omega, nsz);   % Observed_set
    C = reshape(X, nsz);
    ksz = round(nsz);   % set the size of sketching

%% Rank Estimation   
    for i = 1:d
        Cn = double(tenmat(C,i));
        Ob = double(tenmat(O,i));
        [~,Cc]=size(Cn);
        if skt
            ksz(i) = min(ksz(i),round(Cc/5));
            Wn = randn(Cc,ksz(i));
            Cn = Cn*Wn;
            Ob = Ob*Wn;
        end
        if miss
            [U{i},S{i},V{i},J(i)] = iter_SVT(Cn, Ob, rho, ep);
        else
            tau = ep*norm(Cn)/sqrt(d);
            [~,U{i},S{i},V{i},J(i)] = SVT(Cn, tau);
        end
    end

    alpha = sqrt(prod(J(1:d)));

    for s = 1:d
        indices = mod((s + (1:2:d-2)) - 1, d) + 1;
        R(s) = round(alpha / prod(J(indices)));
    end

    if d ~= td
        if sz(td) ~= sz(td-1)
            idx = find(sz==max(sz(td), sz(td-1)));
        else
            idx = td;
        end
        Cn = double(tenmat(X, idx));
        Ob = double(tenmat(Omega, idx));

        if supc
            new_sz = [prod(sz(1:t)), prod(sz(t+1:end))];
        else
            new_sz = [sz(1), prod(sz(2:end))];
        end
        Cn = reshape(Cn, new_sz);
        Ob = reshape(Omega, new_sz);

        [Cr,Cc]=size(Cn);
        if skt
            temp= min(Cr,round(Cc/5));
            Wn = randn(Cc,temp);
            Cn = Cn*Wn;
            Ob = Ob*Wn;
        end
        if miss
            [U{idx},S{idx},V{idx},J(idx)] = iter_SVT(Cn, Ob, rho, ep);
        else
            tau = ep*norm(Cn)/sqrt(d);
            [~,U{idx},S{idx},V{idx},J(idx)] = SVT(Cn, tau);
        end
        if idx == td
            R(td) = round(J(idx)/R(1));
        else
            R(td) = round(J(idx)/R(td-1));
        end
    end




