% test_demo for real_world data

close; clear; clc


%% add path
addpath (genpath('./main_algs/'))
addpath (genpath('./Support_Toolbox/'))
addpath ('./data/')
%%%%%%%%%%%% set up %%%%%%%%%%%%%
noisy = 1;
miss = 0;   % incomplete or not
skt = 0; % sketching or not
Algs = {'Proposed'};
ep = 1.71e-2;

%%%%%%%%%%%% load data %%%%%%%%%%%
filename = 'toy';
load(strcat(filename,'.mat'))
tdata = all_images;

T = double(tdata);
norm_T = norm(tensor(T));
sz = size(T);
d = length(sz);
disp([ 'Data size =', num2str(sz)]);
disp('===================================');


 %% Add noise
if noisy
    SNR = 15;
    data = addnoise(T,SNR);
    disp([ 'Noisy case with SNR = ', num2str(SNR), 'dB']);
    disp('===================================');
else
    data = T;
    disp( 'NoiseFree case.');
    disp('===================================');
end


%% Add　mask
if miss
    rho = 1e-4;
    mr = 0.9;
    W = gen_W(sz,mr);
    Z = W.*data;
    disp([ 'Incomplete case with MR = ', num2str(mr)]);
    disp('===================================');
else
    rho = [];
    mr = 0;
    W = ones(sz);  
    Z=data;
    disp('Complete case.');
    disp('===================================');
end

runs = 10;  % test runs 
Time = zeros(1,runs);  
RSE = Time;
PSNR = RSE;
SSIM = PSNR;
CR = SSIM;
EstRank = zeros(d,runs);

%%  Comparison
    for it = 1:runs    
                c=tic;
                [J, R, S] = rankEst_odd(Z, W, skt, miss, ep, rho);
                if miss
                    para.r = R;
                    para.max_iter= 50;  
                    para.max_tot=10^-6;
                    para.tol=10^-6;
                    para.disp =0;
                    para.printitn = 0; 
                    tr = Completion_TR(Z, W, para);
                    X = coreten2tr(tr);
                else
                    tr = tr_ALS(Z,1e-6,R,20); 
                    X = fold1(tr);
                end
                Time(it) = toc(c); 
                X = reshape(X,sz);
                EstRank(:,it) = R;
                RSE(it) = norm(X(:)-T(:))/norm_T;    
                CR(it) = ComRatio(sz, R);
                PSNR(it) = PSNR_RGB(X,T);                 
                SSIM(it) = mSSIM(X,T);
    end
    Rn = round(mean(EstRank(:,:),2))';
    disp(['============= The Results of ', Algs,' =============']);
    disp([ 'Estimated Rank = ', num2str(Rn)]);
    disp([ 'Time  = ', num2str(mean(Time))]);
    disp([ 'RSE  = ', num2str(mean(RSE))]);
    disp([ 'CR  = ', num2str(mean(CR))]);
    disp([ 'PSNR  = ', num2str(mean(PSNR))]);
    disp([ 'SSIM  = ', num2str(mean(SSIM))]);

