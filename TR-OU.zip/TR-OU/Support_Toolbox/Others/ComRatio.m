function CR = ComRatio(dims, ranks)
% Compression Ratio: num(Original)/num(TR-cores)

R = [ranks,ranks(1)];
D = dims;
N = numel(dims);
B = prod(D(:));
A = 0;

 for n = 1:N
     Cn = R(n)*D(n)*R(n+1);
     A = A+Cn;
 end

CR = B/A;
 

