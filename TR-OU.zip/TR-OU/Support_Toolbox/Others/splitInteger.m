function dn = splitInteger(d)
% Script for assigning the number of merge dimensions

    q = floor(d/3);

    a = q;
    b = q;
    c = q;
    
    if mod(d, 3) ~= 0
        excess = mod(d, 3);
        if excess >= 2
            a = a + excess-1;
            b = b + excess-1;
        else
            c = c + excess;
        end
    end

dn = [a,b,c]; 
